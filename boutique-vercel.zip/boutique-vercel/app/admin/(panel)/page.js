import { redirect } from 'next/navigation';
import { getRole } from '@/lib/auth';
import { db } from '@/lib/db';
import { money } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function Dashboard() {
  if ((await getRole()) !== 'admin') redirect('/admin/commandes');
  const sql = await db();
  const [all, today, pending, days, top] = await Promise.all([
    sql`SELECT COALESCE(SUM(total),0) AS revenue, COUNT(*)::int AS n FROM orders WHERE status <> 'annulee'`,
    sql`SELECT COALESCE(SUM(total),0) AS revenue, COUNT(*)::int AS n FROM orders
        WHERE status <> 'annulee' AND created_at >= date_trunc('day', now())`,
    sql`SELECT COUNT(*)::int AS n FROM orders WHERE status = 'nouvelle'`,
    sql`SELECT to_char(d::date, 'DD/MM') AS day, COALESCE(SUM(o.total),0) AS total, COUNT(o.id)::int AS n
        FROM generate_series(current_date - 6, current_date, interval '1 day') d
        LEFT JOIN orders o ON o.created_at::date = d::date AND o.status <> 'annulee'
        GROUP BY d ORDER BY d`,
    sql`SELECT oi.name, SUM(oi.quantity)::int AS qty, SUM(oi.quantity * oi.price) AS revenue
        FROM order_items oi JOIN orders o ON o.id = oi.order_id
        WHERE o.status <> 'annulee'
        GROUP BY oi.name ORDER BY qty DESC LIMIT 5`,
  ]);

  const max = Math.max(1, ...days.map((d) => Number(d.total)));

  return (
    <div className="page">
      <h1>Tableau de bord</h1>
      <div className="stats">
        <div className="stat"><div className="v">{money(all[0].revenue)}</div><div className="l">Ventes totales ({all[0].n} commandes)</div></div>
        <div className="stat"><div className="v">{money(today[0].revenue)}</div><div className="l">Ventes aujourd&apos;hui ({today[0].n})</div></div>
        <div className="stat"><div className="v">{pending[0].n}</div><div className="l">Commandes à traiter</div></div>
        <div className="stat">
          <div className="v">{all[0].n > 0 ? money(Number(all[0].revenue) / all[0].n) : money(0)}</div>
          <div className="l">Panier moyen</div>
        </div>
      </div>

      <div className="two">
        <section className="box">
          <h2>Ventes des 7 derniers jours</h2>
          <div className="bars">
            {days.map((d) => (
              <div className="bar" key={d.day}>
                <span>{d.day}</span>
                <div className="track"><div className="fill" style={{ width: `${(Number(d.total) / max) * 100}%` }} /></div>
                <span>{money(d.total)}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="box">
          <h2>Articles les plus vendus</h2>
          {top.length === 0 ? (
            <p className="muted">Aucune vente pour le moment.</p>
          ) : (
            <table className="simple">
              <thead><tr><th>Article</th><th className="num">Vendus</th><th className="num">Total</th></tr></thead>
              <tbody>
                {top.map((t) => (
                  <tr key={t.name}><td>{t.name}</td><td className="num">{t.qty}</td><td className="num">{money(t.revenue)}</td></tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </div>
    </div>
  );
}
