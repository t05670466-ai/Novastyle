import { redirect } from 'next/navigation';
import { getRole } from '@/lib/auth';
import { db } from '@/lib/db';
import ProductManager from '@/components/ProductManager';

export const dynamic = 'force-dynamic';

export default async function ProductsPage() {
  if ((await getRole()) !== 'admin') redirect('/admin/commandes');
  const sql = await db();
  const rows = await sql`
    SELECT id, name, description, price, category, sizes, image_url, available
    FROM products ORDER BY created_at DESC`;
  const products = rows.map((p) => ({ ...p, price: Number(p.price) }));
  return (
    <div className="page">
      <h1>Articles</h1>
      <ProductManager products={products} />
    </div>
  );
}
