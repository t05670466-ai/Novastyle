import { redirect } from 'next/navigation';
import { getRole } from '@/lib/auth';
import AdminNav from '@/components/AdminNav';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Administration', robots: { index: false, follow: false } };

export default async function PanelLayout({ children }) {
  const role = await getRole();
  if (!role) redirect('/admin/login');
  return (
    <>
      <AdminNav role={role} />
      <main className="wrap">{children}</main>
    </>
  );
}
