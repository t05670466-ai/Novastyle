import Link from 'next/link';
import { notFound } from 'next/navigation';
import { db } from '@/lib/db';
import PrintButton from '@/components/PrintButton';
import { SHOP_NAME, SHOP_CONTACT } from '@/lib/config';
import { dateTime, money } from '@/lib/format';

export const dynamic = 'force-dynamic';

export default async function Slip({ params }) {
  const { id } = await params;
  if (!/^\d+$/.test(id)) notFound();
  const sql = await db();
  const orders = await sql`SELECT * FROM orders WHERE id = ${Number(id)}`;
  const o = orders[0];
  if (!o) notFound();
  const items = await sql`SELECT name, size, price, quantity FROM order_items WHERE order_id = ${o.id} ORDER BY id`;

  return (
    <>
      <div className="wrap no-print" style={{ paddingTop: 16, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        <PrintButton />
        <Link className="btn ghost" href="/admin/commandes">← Retour aux commandes</Link>
      </div>
      <section className="slip">
        <div className="head">
          <div>
            <h1>Bon de livraison</h1>
            <div>N°{o.id} — {dateTime(o.created_at)}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <strong>{SHOP_NAME}</strong>
            {SHOP_CONTACT && <div>{SHOP_CONTACT}</div>}
          </div>
        </div>
        <div>
          <strong>Client :</strong> {o.customer_name}<br />
          <strong>Téléphone :</strong> {o.phone}<br />
          <strong>Adresse :</strong> {o.address}
          {o.note && (<><br /><strong>Précision :</strong> {o.note}</>)}
        </div>
        <table>
          <thead>
            <tr><th>Article</th><th>Taille</th><th className="num">Qté</th><th className="num">Prix unitaire</th><th className="num">Total</th></tr>
          </thead>
          <tbody>
            {items.map((i, k) => (
              <tr key={k}>
                <td>{i.name}</td>
                <td>{i.size || '—'}</td>
                <td className="num">{i.quantity}</td>
                <td className="num">{money(i.price)}</td>
                <td className="num">{money(Number(i.price) * i.quantity)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr><th colSpan={4} className="num">Total à payer</th><th className="num">{money(o.total)}</th></tr>
          </tfoot>
        </table>
        <div className="sign">
          <div>Signature du livreur</div>
          <div>Signature du client</div>
        </div>
      </section>
    </>
  );
}
