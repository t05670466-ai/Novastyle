import { db } from '@/lib/db';
import OrderList from '@/components/OrderList';

export const dynamic = 'force-dynamic';

export default async function OrdersPage() {
  const sql = await db();
  const orders = await sql`
    SELECT o.id, o.customer_name, o.phone, o.address, o.note, o.total, o.status, o.created_at,
      COALESCE(
        json_agg(json_build_object('name', oi.name, 'size', oi.size, 'price', oi.price, 'quantity', oi.quantity)
                 ORDER BY oi.id) FILTER (WHERE oi.id IS NOT NULL),
        '[]'::json) AS items
    FROM orders o LEFT JOIN order_items oi ON oi.order_id = o.id
    GROUP BY o.id ORDER BY o.id DESC LIMIT 200`;
  const plain = orders.map((o) => ({ ...o, created_at: new Date(o.created_at).toISOString() }));
  return (
    <div className="page">
      <h1>Commandes</h1>
      <OrderList orders={plain} />
    </div>
  );
}
