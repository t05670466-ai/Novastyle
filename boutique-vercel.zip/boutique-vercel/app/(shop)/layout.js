import { CartProvider } from '@/components/CartProvider';
import Header from '@/components/Header';
import { SHOP_NAME, SHOP_CONTACT } from '@/lib/config';

export default function ShopLayout({ children }) {
  return (
    <CartProvider>
      <Header shopName={SHOP_NAME} />
      <main className="wrap">{children}</main>
      <footer className="foot">
        <div className="wrap">
          {SHOP_NAME}
          {SHOP_CONTACT ? ` — ${SHOP_CONTACT}` : ''}
        </div>
      </footer>
    </CartProvider>
  );
}
