'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { useCart } from '@/components/CartProvider';
import { money } from '@/lib/format';

export default function CartPage() {
  const { items, ready, setQty, remove, clear, total } = useCart();
  const router = useRouter();
  const [form, setForm] = useState({ name: '', phone: '', address: '', note: '' });
  const [error, setError] = useState('');
  const [sending, setSending] = useState(false);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setError('');
    setSending(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          items: items.map((i) => ({ productId: i.productId, size: i.size, quantity: i.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Une erreur est survenue.');
        setSending(false);
        return;
      }
      clear();
      router.push(`/commande/merci?n=${data.id}`);
    } catch {
      setError('Connexion impossible. Vérifie ton réseau et réessaie.');
      setSending(false);
    }
  }

  if (!ready) return <div className="cart"><p className="muted">Chargement du panier…</p></div>;

  if (items.length === 0) {
    return (
      <div className="empty">
        <h2>Ton panier est vide</h2>
        <p className="muted">Ajoute un ou plusieurs articles, puis reviens ici pour commander.</p>
        <p><Link href="/" className="btn accent">Voir les articles</Link></p>
      </div>
    );
  }

  return (
    <div className="cart">
      <section>
        <h1>Ton panier</h1>
        {items.map((i) => (
          <div className="line" key={i.key}>
            <div className="thumb">
              {i.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={i.image} alt="" />
              ) : (
                i.name.slice(0, 1).toUpperCase()
              )}
            </div>
            <div className="info">
              <div className="name">{i.name}</div>
              <div className="muted">
                {i.size ? `Taille ${i.size} · ` : ''}
                {money(i.price)}
              </div>
              <div className="row">
                <div className="qty">
                  <button type="button" aria-label="Moins" onClick={() => setQty(i.key, i.quantity - 1)}>−</button>
                  <span>{i.quantity}</span>
                  <button type="button" aria-label="Plus" onClick={() => setQty(i.key, i.quantity + 1)}>+</button>
                </div>
                <strong>{money(i.price * i.quantity)}</strong>
                <button type="button" className="linkbtn" onClick={() => remove(i.key)}>Retirer</button>
              </div>
            </div>
          </div>
        ))}
        <div className="total">
          <span>Total</span>
          <span>{money(total)}</span>
        </div>
        <Link href="/" className="back">← Continuer mes achats</Link>
      </section>

      <form className="panel" onSubmit={submit}>
        <h2>Tes informations de livraison</h2>
        <label className="field">
          Nom complet
          <input type="text" value={form.name} onChange={update('name')} required autoComplete="name" />
        </label>
        <label className="field">
          Téléphone
          <input type="tel" value={form.phone} onChange={update('phone')} required autoComplete="tel" />
        </label>
        <label className="field">
          Adresse de livraison
          <textarea value={form.address} onChange={update('address')} required autoComplete="street-address" />
        </label>
        <label className="field">
          Précision pour la commande <span className="hint">(facultatif)</span>
          <textarea value={form.note} onChange={update('note')} />
        </label>
        {error && <p className="msg error" role="alert">{error}</p>}
        <button type="submit" className="btn accent" disabled={sending}>
          {sending ? 'Envoi en cours…' : `Commander (${money(total)})`}
        </button>
      </form>
    </div>
  );
}
