import { db } from '@/lib/db';
import ProductBrowser from '@/components/ProductBrowser';
import { SHOP_NAME, SHOP_TAGLINE } from '@/lib/config';

export const dynamic = 'force-dynamic';

export default async function Home() {
  let products = [];
  let failed = false;
  try {
    const sql = await db();
    products = await sql`
      SELECT id, name, price, category, image_url
      FROM products WHERE available ORDER BY created_at DESC`;
  } catch (e) {
    console.error(e);
    failed = true;
  }

  return (
    <>
      <section className="hero">
        <h1>{SHOP_NAME}</h1>
        <p>{SHOP_TAGLINE}</p>
      </section>
      {failed ? (
        <div className="empty">
          <h2>La boutique n&apos;est pas encore prête</h2>
          <p className="muted">
            La base de données n&apos;est pas connectée. Vérifie la variable DATABASE_URL dans les
            réglages du projet sur Vercel.
          </p>
        </div>
      ) : products.length === 0 ? (
        <div className="empty">
          <h2>Aucun article pour le moment</h2>
          <p className="muted">Reviens bientôt : de nouveaux habits arrivent.</p>
        </div>
      ) : (
        <ProductBrowser products={products} />
      )}
    </>
  );
}
