import Link from 'next/link';

export const metadata = { title: 'Commande envoyée' };

export default async function Thanks({ searchParams }) {
  const { n } = await searchParams;
  return (
    <div className="thanks">
      <h1>Commande envoyée</h1>
      <p>
        {n && /^\d+$/.test(n) ? `Ta commande n°${n} est bien enregistrée. ` : 'Ta commande est bien enregistrée. '}
        La boutique va te contacter par téléphone pour confirmer la livraison.
      </p>
      <p><Link href="/" className="btn accent">Retour aux articles</Link></p>
    </div>
  );
}
