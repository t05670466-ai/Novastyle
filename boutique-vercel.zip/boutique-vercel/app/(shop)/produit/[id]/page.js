import Link from 'next/link';
import { notFound } from 'next/navigation';
import { db } from '@/lib/db';
import AddToCart from '@/components/AddToCart';
import { money } from '@/lib/format';

export const dynamic = 'force-dynamic';

export async function generateMetadata({ params }) {
  const { id } = await params;
  if (!/^\d+$/.test(id)) return {};
  try {
    const sql = await db();
    const rows = await sql`SELECT name FROM products WHERE id = ${Number(id)}`;
    return rows[0] ? { title: rows[0].name } : {};
  } catch {
    return {};
  }
}

export default async function ProductPage({ params }) {
  const { id } = await params;
  if (!/^\d+$/.test(id)) notFound();
  const sql = await db();
  const rows = await sql`
    SELECT id, name, description, price, category, sizes, image_url, available
    FROM products WHERE id = ${Number(id)}`;
  const p = rows[0];
  if (!p || !p.available) notFound();
  const sizes = p.sizes.split(',').map((s) => s.trim()).filter(Boolean);
  const product = { id: p.id, name: p.name, price: Number(p.price), image_url: p.image_url };

  return (
    <>
      <Link href="/" className="back">← Tous les articles</Link>
      <article className="detail">
        <div className="photo">
          {p.image_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={p.image_url} alt={p.name} />
          ) : (
            <span className="initial" style={{ font: '800 96px var(--display)', color: 'var(--accent)' }}>
              {p.name.slice(0, 1).toUpperCase()}
            </span>
          )}
        </div>
        <div>
          <h1>{p.name}</h1>
          <div className="price">{money(p.price)}</div>
          {p.description && <p className="desc">{p.description}</p>}
          <AddToCart product={product} sizes={sizes} />
        </div>
      </article>
    </>
  );
}
