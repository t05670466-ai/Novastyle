import { NextResponse } from 'next/server';
import { identify, makeToken, COOKIE_NAME, cookieOptions } from '@/lib/auth';

export async function POST(request) {
  let body = {};
  try {
    body = await request.json();
  } catch {}
  if (!process.env.ADMIN_PASSWORD) {
    return NextResponse.json({ error: 'ADMIN_PASSWORD n\'est pas défini sur Vercel.' }, { status: 500 });
  }
  const role = identify(body.password);
  if (!role) {
    await new Promise((r) => setTimeout(r, 800));
    return NextResponse.json({ error: 'Mot de passe incorrect.' }, { status: 401 });
  }
  const res = NextResponse.json({ ok: true, role });
  res.cookies.set(COOKIE_NAME, makeToken(role), cookieOptions);
  return res;
}
