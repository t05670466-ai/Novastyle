import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { cleanProduct } from '@/lib/products';

export async function POST(request) {
  const denied = await requireAdmin();
  if (denied) return denied;
  const { value, error } = cleanProduct(await request.json());
  if (error) return Response.json({ error }, { status: 400 });
  const sql = await db();
  const rows = await sql`
    INSERT INTO products (name, description, price, category, sizes, image_url, available)
    VALUES (${value.name}, ${value.description}, ${value.price}, ${value.category}, ${value.sizes}, ${value.image_url}, ${value.available})
    RETURNING id`;
  return Response.json({ id: rows[0].id });
}
