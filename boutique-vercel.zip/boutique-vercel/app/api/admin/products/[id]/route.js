import { db } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import { cleanProduct } from '@/lib/products';

export async function PUT(request, { params }) {
  const denied = await requireAdmin();
  if (denied) return denied;
  const { id } = await params;
  const { value, error } = cleanProduct(await request.json());
  if (error) return Response.json({ error }, { status: 400 });
  const sql = await db();
  await sql`
    UPDATE products SET
      name = ${value.name}, description = ${value.description}, price = ${value.price},
      category = ${value.category}, sizes = ${value.sizes}, image_url = ${value.image_url},
      available = ${value.available}
    WHERE id = ${Number(id)}`;
  return Response.json({ ok: true });
}

export async function DELETE(_request, { params }) {
  const denied = await requireAdmin();
  if (denied) return denied;
  const { id } = await params;
  const sql = await db();
  await sql`DELETE FROM products WHERE id = ${Number(id)}`;
  return Response.json({ ok: true });
}
