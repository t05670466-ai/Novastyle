import { db } from '@/lib/db';
import { requireStaff } from '@/lib/auth';
import { STATUSES } from '@/lib/format';

export async function PATCH(request, { params }) {
  const denied = await requireStaff();
  if (denied) return denied;
  const { id } = await params;
  const { status } = await request.json();
  if (!Object.keys(STATUSES).includes(status)) {
    return Response.json({ error: 'Statut invalide' }, { status: 400 });
  }
  const sql = await db();
  await sql`UPDATE orders SET status = ${status} WHERE id = ${Number(id)}`;
  return Response.json({ ok: true });
}
