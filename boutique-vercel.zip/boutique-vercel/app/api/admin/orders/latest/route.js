import { db } from '@/lib/db';
import { requireStaff } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET() {
  const denied = await requireStaff();
  if (denied) return denied;
  const sql = await db();
  const rows = await sql`
    SELECT COALESCE(MAX(id), 0)::int AS last_id,
           COUNT(*) FILTER (WHERE status = 'nouvelle')::int AS pending
    FROM orders`;
  return Response.json({ lastId: rows[0].last_id, pending: rows[0].pending });
}
