import { put } from '@vercel/blob';
import { requireAdmin } from '@/lib/auth';

export async function POST(request) {
  const denied = await requireAdmin();
  if (denied) return denied;

  if (!process.env.BLOB_READ_WRITE_TOKEN) {
    return Response.json(
      { error: 'Le stockage de photos (Blob) n\'est pas connecté au projet Vercel.' },
      { status: 500 }
    );
  }
  const form = await request.formData();
  const file = form.get('file');
  if (!file || typeof file === 'string') {
    return Response.json({ error: 'Aucune photo reçue.' }, { status: 400 });
  }
  if (!file.type.startsWith('image/')) {
    return Response.json({ error: 'Le fichier doit être une image.' }, { status: 400 });
  }
  if (file.size > 4 * 1024 * 1024) {
    return Response.json({ error: 'Photo trop lourde (4 Mo maximum).' }, { status: 400 });
  }
  try {
    const name = `produits/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
    const blob = await put(name, file, { access: 'public', contentType: file.type });
    return Response.json({ url: blob.url });
  } catch (e) {
    console.error(e);
    return Response.json({ error: 'Envoi de la photo impossible.' }, { status: 500 });
  }
}
