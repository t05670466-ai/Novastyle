import { db } from '@/lib/db';
import { sendOrderEmail } from '@/lib/notify';

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: 'Requête invalide' }, { status: 400 });
  }

  const name = String(body.name || '').trim().slice(0, 120);
  const phone = String(body.phone || '').trim().slice(0, 40);
  const address = String(body.address || '').trim().slice(0, 300);
  const note = String(body.note || '').trim().slice(0, 500);
  const rawItems = Array.isArray(body.items) ? body.items.slice(0, 50) : [];

  if (!name || !phone || !address) {
    return Response.json({ error: 'Nom, téléphone et adresse sont obligatoires.' }, { status: 400 });
  }
  if (rawItems.length === 0) {
    return Response.json({ error: 'Le panier est vide.' }, { status: 400 });
  }

  const ids = [...new Set(rawItems.map((i) => Number(i.productId)).filter(Number.isInteger))];
  if (ids.length === 0) {
    return Response.json({ error: 'Panier invalide.' }, { status: 400 });
  }

  try {
    const sql = await db();
    const products = await sql`SELECT id, name, price, sizes, available FROM products WHERE id = ANY(${ids}::int[])`;
    const byId = new Map(products.map((p) => [p.id, p]));

    const items = [];
    let total = 0;
    for (const it of rawItems) {
      const p = byId.get(Number(it.productId));
      if (!p || !p.available) {
        return Response.json(
          { error: 'Un article de ton panier n\'est plus disponible. Retire-le et réessaie.' },
          { status: 400 }
        );
      }
      const quantity = Math.max(1, Math.min(20, parseInt(it.quantity, 10) || 1));
      const sizes = p.sizes.split(',').map((s) => s.trim()).filter(Boolean);
      const size = String(it.size || '').trim();
      if (sizes.length > 0 && !sizes.includes(size)) {
        return Response.json({ error: `Choisis une taille pour « ${p.name} ».` }, { status: 400 });
      }
      const price = Number(p.price);
      total += price * quantity;
      items.push({ product_id: p.id, name: p.name, size: sizes.length ? size : '', price, quantity });
    }

    // Commande + articles dans une seule requête (tout ou rien)
    const rows = await sql`
      WITH o AS (
        INSERT INTO orders (customer_name, phone, address, note, total)
        VALUES (${name}, ${phone}, ${address}, ${note}, ${total})
        RETURNING id
      )
      INSERT INTO order_items (order_id, product_id, name, size, price, quantity)
      SELECT o.id, x.product_id, x.name, x.size, x.price, x.quantity
      FROM o, jsonb_to_recordset(${JSON.stringify(items)}::jsonb)
        AS x(product_id int, name text, size text, price numeric, quantity int)
      RETURNING order_id`;

    const orderId = rows[0].order_id;
    await sendOrderEmail({ id: orderId, name, phone, address, note, total }, items);
    return Response.json({ id: orderId });
  } catch (e) {
    console.error(e);
    return Response.json({ error: 'Impossible d\'enregistrer la commande. Réessaie dans un instant.' }, { status: 500 });
  }
}
