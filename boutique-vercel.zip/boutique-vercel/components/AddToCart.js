'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useCart } from './CartProvider';

export default function AddToCart({ product, sizes }) {
  const { add } = useCart();
  const [size, setSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState('');
  const [added, setAdded] = useState(false);

  function onAdd() {
    if (sizes.length > 0 && !size) {
      setError('Choisis une taille.');
      return;
    }
    setError('');
    add(product, size, quantity);
    setAdded(true);
  }

  return (
    <div>
      {sizes.length > 0 && (
        <>
          <strong>Taille</strong>
          <div className="sizes" role="group" aria-label="Taille">
            {sizes.map((s) => (
              <button
                key={s}
                type="button"
                className="size"
                aria-pressed={size === s}
                onClick={() => {
                  setSize(s);
                  setError('');
                  setAdded(false);
                }}
              >
                {s}
              </button>
            ))}
          </div>
        </>
      )}
      <div className="buyrow">
        <div className="qty">
          <button type="button" aria-label="Moins" onClick={() => setQuantity((q) => Math.max(1, q - 1))}>−</button>
          <span aria-live="polite">{quantity}</span>
          <button type="button" aria-label="Plus" onClick={() => setQuantity((q) => Math.min(20, q + 1))}>+</button>
        </div>
        <button type="button" className="btn accent" onClick={onAdd}>Ajouter au panier</button>
      </div>
      {error && <p className="msg error" role="alert" style={{ marginTop: 12 }}>{error}</p>}
      {added && (
        <p className="msg ok" role="status" style={{ marginTop: 12 }}>
          Ajouté au panier. <Link href="/panier"><strong>Voir le panier</strong></Link> ou continue tes achats.
        </p>
      )}
    </div>
  );
}
