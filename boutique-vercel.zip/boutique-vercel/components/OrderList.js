'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { STATUSES, dateTime, money } from '@/lib/format';

export default function OrderList({ orders }) {
  const router = useRouter();
  const [error, setError] = useState('');

  async function setStatus(id, status) {
    setError('');
    const res = await fetch(`/api/admin/orders/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (!res.ok) setError('Le statut n\'a pas pu être modifié.');
    router.refresh();
  }

  if (orders.length === 0) return <p className="muted">Aucune commande pour le moment.</p>;

  return (
    <div className="orders">
      {error && <p className="msg error" role="alert">{error}</p>}
      {orders.map((o) => (
        <article key={o.id} className={`order ${o.status === 'nouvelle' ? 'new' : ''}`}>
          <header>
            <span className="num">Commande n°{o.id}</span>
            <span className="muted">{dateTime(o.created_at)}</span>
          </header>
          <div>
            <strong>{o.customer_name}</strong> — <a href={`tel:${o.phone}`}>{o.phone}</a>
            <div>{o.address}</div>
            {o.note && <div className="muted">Précision : {o.note}</div>}
          </div>
          <ul>
            {o.items.map((i, k) => (
              <li key={k}>
                {i.quantity} × {i.name}
                {i.size ? ` (taille ${i.size})` : ''} — {money(i.price * i.quantity)}
              </li>
            ))}
          </ul>
          <div className="tools">
            <strong>Total : {money(o.total)}</strong>
            <select
              aria-label={`Statut de la commande ${o.id}`}
              value={o.status}
              onChange={(e) => setStatus(o.id, e.target.value)}
            >
              {Object.entries(STATUSES).map(([k, label]) => (
                <option key={k} value={k}>{label}</option>
              ))}
            </select>
            <Link className="btn small" href={`/admin/commandes/${o.id}/bon`}>Bon de livraison</Link>
          </div>
        </article>
      ))}
    </div>
  );
}
