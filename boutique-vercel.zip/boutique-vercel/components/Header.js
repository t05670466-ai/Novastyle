'use client';

import Link from 'next/link';
import { useCart } from './CartProvider';

export default function Header({ shopName }) {
  const { count } = useCart();
  return (
    <header className="topbar">
      <div className="wrap">
        <Link href="/" className="brand">{shopName}</Link>
        <Link href="/panier" className="cartlink" aria-label={`Panier, ${count} article(s)`}>
          Panier
          <span className={`badge ${count === 0 ? 'zero' : ''}`}>{count}</span>
        </Link>
      </div>
    </header>
  );
}
