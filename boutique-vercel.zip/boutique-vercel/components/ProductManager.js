'use client';

import { useRouter } from 'next/navigation';
import { useRef, useState } from 'react';
import { money } from '@/lib/format';

const EMPTY = { id: null, name: '', price: '', category: '', sizes: '', description: '', image_url: '', available: true };

// Réduit la photo (téléphone) avant l'envoi : plus rapide et sous la limite de Vercel.
function compress(file, max = 1200) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const ratio = Math.min(1, max / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * ratio);
      canvas.height = Math.round(img.height * ratio);
      canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(
        (blob) => {
          URL.revokeObjectURL(url);
          blob ? resolve(blob) : reject(new Error('compression'));
        },
        'image/jpeg',
        0.82
      );
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('lecture'));
    };
    img.src = url;
  });
}

export default function ProductManager({ products }) {
  const router = useRouter();
  const formRef = useRef(null);
  const [form, setForm] = useState(EMPTY);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState('');

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function onPhoto(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError('');
    setUploading(true);
    try {
      const blob = await compress(file);
      const fd = new FormData();
      fd.append('file', blob, 'photo.jpg');
      const res = await fetch('/api/admin/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Envoi impossible.');
      setForm((f) => ({ ...f, image_url: data.url }));
    } catch (err) {
      setError(err.message || 'Envoi de la photo impossible.');
    }
    setUploading(false);
    e.target.value = '';
  }

  async function save(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    setDone('');
    const res = await fetch(form.id ? `/api/admin/products/${form.id}` : '/api/admin/products', {
      method: form.id ? 'PUT' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error || 'Enregistrement impossible.');
      return;
    }
    setDone(form.id ? 'Article modifié.' : 'Article ajouté.');
    setForm(EMPTY);
    router.refresh();
  }

  async function toggle(p) {
    await fetch(`/api/admin/products/${p.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...p, available: !p.available }),
    });
    router.refresh();
  }

  async function remove(p) {
    if (!window.confirm(`Supprimer « ${p.name} » ? Les anciennes commandes sont conservées.`)) return;
    await fetch(`/api/admin/products/${p.id}`, { method: 'DELETE' });
    router.refresh();
  }

  function edit(p) {
    setForm({ ...p, price: String(p.price) });
    setDone('');
    setError('');
    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  return (
    <>
      <form className="panel" onSubmit={save} ref={formRef}>
        <h2>{form.id ? 'Modifier l\'article' : 'Ajouter un article'}</h2>

        <div className="photoedit">
          <div className="preview">
            {form.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={form.image_url} alt="Aperçu" />
            ) : (
              'Pas de photo'
            )}
          </div>
          <label className="field">
            Photo de l&apos;habit
            <input type="file" accept="image/*" onChange={onPhoto} disabled={uploading} />
            <span className="hint">{uploading ? 'Envoi de la photo…' : 'Choisis une photo dans ta galerie ou prends-en une.'}</span>
          </label>
        </div>

        <div className="formgrid cols">
          <label className="field">
            Nom
            <input type="text" value={form.name} onChange={set('name')} required />
          </label>
          <label className="field">
            Prix
            <input type="number" inputMode="decimal" step="any" min="0" value={form.price} onChange={set('price')} required />
          </label>
          <label className="field">
            Catégorie <span className="hint">(ex : Homme, Femme, Enfant)</span>
            <input type="text" value={form.category} onChange={set('category')} />
          </label>
          <label className="field">
            Tailles <span className="hint">(séparées par des virgules, ex : S,M,L,XL)</span>
            <input type="text" value={form.sizes} onChange={set('sizes')} />
          </label>
        </div>
        <label className="field">
          Description
          <textarea value={form.description} onChange={set('description')} />
        </label>

        {error && <p className="msg error" role="alert">{error}</p>}
        {done && <p className="msg ok" role="status">{done}</p>}

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button className="btn accent" disabled={busy || uploading}>
            {busy ? 'Enregistrement…' : form.id ? 'Enregistrer les changements' : 'Ajouter l\'article'}
          </button>
          {form.id && (
            <button type="button" className="btn ghost" onClick={() => setForm(EMPTY)}>Annuler</button>
          )}
        </div>
      </form>

      <section>
        <h2 style={{ fontSize: 22, marginBottom: 12 }}>Tous les articles ({products.length})</h2>
        {products.length === 0 ? (
          <p className="muted">Aucun article pour le moment. Ajoute le premier ci-dessus.</p>
        ) : (
          <div className="plist">
            {products.map((p) => (
              <div className="prow" key={p.id}>
                <div className="thumb">
                  {p.image_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={p.image_url} alt="" />
                  ) : (
                    p.name.slice(0, 1).toUpperCase()
                  )}
                </div>
                <div className="meta">
                  <strong>{p.name}</strong>
                  <span>
                    {money(p.price)} {p.category && <span className="tag">{p.category}</span>}{' '}
                    {!p.available && <span className="tag off">Masqué</span>}
                  </span>
                  {p.sizes && <span className="muted">Tailles : {p.sizes}</span>}
                  <div className="actions">
                    <button className="btn small" onClick={() => edit(p)}>Modifier</button>
                    <button className="btn small ghost" onClick={() => toggle(p)}>
                      {p.available ? 'Masquer' : 'Afficher'}
                    </button>
                    <button className="btn small danger" onClick={() => remove(p)}>Supprimer</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </>
  );
}
