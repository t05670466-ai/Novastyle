'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';

const CartContext = createContext(null);
const KEY = 'panier_v1';

export function CartProvider({ children }) {
  const [items, setItems] = useState([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) {
      try {
        localStorage.setItem(KEY, JSON.stringify(items));
      } catch {}
    }
  }, [items, ready]);

  const value = useMemo(() => {
    const add = (product, size, quantity = 1) =>
      setItems((prev) => {
        const key = `${product.id}|${size || ''}`;
        if (prev.some((i) => i.key === key)) {
          return prev.map((i) =>
            i.key === key ? { ...i, quantity: Math.min(20, i.quantity + quantity) } : i
          );
        }
        return [
          ...prev,
          {
            key,
            productId: product.id,
            name: product.name,
            price: Number(product.price),
            image: product.image_url || '',
            size: size || '',
            quantity,
          },
        ];
      });
    const setQty = (key, quantity) =>
      setItems((prev) =>
        prev.map((i) => (i.key === key ? { ...i, quantity: Math.max(1, Math.min(20, quantity)) } : i))
      );
    const remove = (key) => setItems((prev) => prev.filter((i) => i.key !== key));
    const clear = () => setItems([]);
    const count = items.reduce((s, i) => s + i.quantity, 0);
    const total = items.reduce((s, i) => s + i.quantity * i.price, 0);
    return { items, ready, add, setQty, remove, clear, count, total };
  }, [items, ready]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  return useContext(CartContext);
}
