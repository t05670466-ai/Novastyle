'use client';

import Link from 'next/link';
import { useCallback, useEffect, useRef, useState } from 'react';

const KEY = 'derniere_commande_vue';

function beep() {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    [0, 0.25].forEach((t, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = i === 0 ? 880 : 1175;
      g.gain.value = 0.15;
      o.connect(g);
      g.connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.2);
    });
  } catch {}
}

// Surveille les nouvelles commandes toutes les 15 secondes tant que l'administration est ouverte.
export default function OrderNotifier({ onPending }) {
  const [fresh, setFresh] = useState(0);
  const [perm, setPerm] = useState('default');
  const baseTitle = useRef('');

  useEffect(() => {
    baseTitle.current = document.title;
    if ('Notification' in window) setPerm(Notification.permission);
  }, []);

  const check = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/orders/latest', { cache: 'no-store' });
      if (!res.ok) return;
      const { lastId, pending } = await res.json();
      onPending?.(pending);
      const seen = Number(localStorage.getItem(KEY) || 0);
      if (seen === 0) {
        localStorage.setItem(KEY, String(lastId));
        return;
      }
      if (lastId > seen) {
        const added = lastId - seen;
        setFresh((n) => n + added);
        beep();
        document.title = `(${added}) Nouvelle commande`;
        if ('Notification' in window && Notification.permission === 'granted') {
          new Notification('Nouvelle commande', { body: `Commande n°${lastId} reçue.` });
        }
        localStorage.setItem(KEY, String(lastId));
      }
    } catch {}
  }, [onPending]);

  useEffect(() => {
    check();
    const t = setInterval(check, 15000);
    return () => clearInterval(t);
  }, [check]);

  async function enable() {
    if (!('Notification' in window)) return;
    const r = await Notification.requestPermission();
    setPerm(r);
    beep();
  }

  function dismiss() {
    setFresh(0);
    document.title = baseTitle.current;
  }

  return (
    <>
      {fresh > 0 && (
        <div className="alertbar" role="alert">
          <div className="wrap">
            <span>{fresh === 1 ? 'Nouvelle commande reçue !' : `${fresh} nouvelles commandes reçues !`}</span>
            <Link href="/admin/commandes" onClick={dismiss}>Voir les commandes</Link>
            <button className="btn small ghost" style={{ color: '#fff', borderColor: '#fff' }} onClick={dismiss}>
              Fermer
            </button>
          </div>
        </div>
      )}
      {perm === 'default' && (
        <div className="wrap" style={{ paddingTop: 12 }}>
          <button className="btn small ghost" onClick={enable}>Activer le son et les notifications</button>
        </div>
      )}
    </>
  );
}
