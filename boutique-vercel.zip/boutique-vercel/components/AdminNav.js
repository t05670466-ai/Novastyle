'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import OrderNotifier from './OrderNotifier';

export default function AdminNav({ role }) {
  const router = useRouter();
  const [pending, setPending] = useState(0);

  async function logout() {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <div className="no-print">
      <nav className="adminbar">
        <div className="wrap">
          {role === 'admin' && <Link href="/admin">Tableau de bord</Link>}
          <Link href="/admin/commandes">
            Commandes
            {pending > 0 && <span className="pending">{pending}</span>}
          </Link>
          {role === 'admin' && <Link href="/admin/produits">Articles</Link>}
          <span className="spacer" />
          <span style={{ opacity: 0.7, fontSize: 14 }}>{role === 'manager' ? 'Gestionnaire' : 'Administrateur'}</span>
          <Link href="/" target="_blank">Voir la boutique</Link>
          <button className="navlink" onClick={logout}>Déconnexion</button>
        </div>
      </nav>
      <OrderNotifier onPending={setPending} />
    </div>
  );
}
