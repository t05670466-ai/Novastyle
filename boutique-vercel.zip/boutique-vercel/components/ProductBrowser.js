'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { money } from '@/lib/format';

export default function ProductBrowser({ products }) {
  const categories = useMemo(
    () => [...new Set(products.map((p) => p.category).filter(Boolean))],
    [products]
  );
  const [active, setActive] = useState('');
  const shown = active ? products.filter((p) => p.category === active) : products;

  return (
    <>
      {categories.length > 0 && (
        <div className="chips" role="group" aria-label="Catégories">
          <button className="chip" aria-pressed={active === ''} onClick={() => setActive('')}>
            Tout
          </button>
          {categories.map((c) => (
            <button key={c} className="chip" aria-pressed={active === c} onClick={() => setActive(c)}>
              {c}
            </button>
          ))}
        </div>
      )}
      <div className="grid">
        {shown.map((p) => (
          <Link key={p.id} href={`/produit/${p.id}`} className="tile">
            <div className="photo">
              {p.image_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={p.image_url} alt={p.name} loading="lazy" />
              ) : (
                <span className="initial">{p.name.slice(0, 1).toUpperCase()}</span>
              )}
            </div>
            <h3>{p.name}</h3>
            <div className="price">{money(p.price)}</div>
          </Link>
        ))}
      </div>
    </>
  );
}
