'use client';

export default function PrintButton() {
  return (
    <button className="btn accent no-print" onClick={() => window.print()}>
      Imprimer le bon
    </button>
  );
}
