# Boutique d'habits : site complet pour Vercel

Ce projet contient tout : la boutique, le panier (plusieurs articles à la fois), la commande,
et une administration protégée par mot de passe (tableau de bord des ventes, ajout d'articles
avec photos, bons de livraison imprimables, alerte à chaque nouvelle commande).

## 1. Personnaliser (2 minutes)
Ouvre `lib/config.js` et change le nom de la boutique, la phrase d'accroche, le contact
(affiché sur le bon de livraison) et la monnaie.

## 2. Mettre le site en ligne sur Vercel
Vercel ne reçoit pas un fichier zip directement : il lit le code depuis GitHub (ou depuis
l'outil Vercel CLI sur ordinateur).

1. Décompresse ce zip.
2. Crée un compte sur github.com, puis un nouveau dépôt (repository), privé de préférence.
3. Envoie-y tout le contenu du dossier (sur GitHub : « Add file » puis « Upload files »).
   Le plus simple est de faire cette étape depuis un ordinateur : l'envoi d'un dossier entier
   est difficile depuis un téléphone.
4. Sur vercel.com, connecte-toi avec GitHub, clique « Add New… » puis « Project »,
   choisis ton dépôt et clique « Deploy ». Le premier essai affichera « La boutique n'est pas
   encore prête » : c'est normal, il manque la base de données (étape suivante).

## 3. Connecter la base de données et les photos
Dans ton projet Vercel, onglet **Storage** :
- **Base de données** : crée une base « Neon » (Postgres, offre gratuite) et connecte-la au projet.
  La variable `DATABASE_URL` est ajoutée toute seule. Les tables se créent automatiquement.
- **Photos** : crée un stockage « Blob » et connecte-le au projet.
  La variable `BLOB_READ_WRITE_TOKEN` est ajoutée toute seule.

## 4. Choisir ton mot de passe d'administration
Onglet **Settings** puis **Environment Variables** : ajoute `ADMIN_PASSWORD` avec un mot de passe
long et difficile à deviner. Ensuite, onglet **Deployments** : « Redeploy » le dernier déploiement
pour que tout soit pris en compte.

## 4 bis. Créer le compte gestionnaire (facultatif)
Toujours dans **Environment Variables**, ajoute `MANAGER_PASSWORD` avec un mot de passe **différent**
de celui de l'administrateur, puis « Redeploy ». La personne se connecte sur la même page
(`ton-adresse/admin`) avec ce mot de passe : le site reconnaît automatiquement son rôle.
- **Gestionnaire** : voit uniquement les commandes (changer le statut, ouvrir et imprimer le bon de
  livraison) et reçoit les alertes de nouvelles commandes. Il ne voit ni les articles ni le tableau de bord.
- **Administrateur** : accès à tout.
Pour retirer l'accès au gestionnaire, change ou supprime `MANAGER_PASSWORD` : sa session s'arrête.

## 5. Utiliser le site
- La boutique : l'adresse de ton projet (en .vercel.app, en HTTPS).
- L'administration : `ton-adresse/admin`
  - **Articles** : ajouter un article avec sa photo, ses tailles (ex : S,M,L), son prix ; modifier, masquer, supprimer.
  - **Commandes** : voir chaque commande, changer son statut, ouvrir le **bon de livraison** et l'imprimer.
  - **Tableau de bord** : ventes totales, ventes du jour, 7 derniers jours, articles les plus vendus.

## Alertes de nouvelles commandes
- Tant que l'administration est ouverte (même en arrière-plan sur le téléphone), la page vérifie
  toutes les 15 secondes : bandeau, petit son, et notification du navigateur si tu les as activées
  (bouton « Activer le son et les notifications »).
- Si l'administration est fermée, il n'y a pas d'alerte sur le téléphone. Pour être prévenu quand
  même, active l'e-mail : crée un compte gratuit sur resend.com, puis ajoute dans Vercel les variables
  `RESEND_API_KEY` (ta clé) et `ADMIN_EMAIL` (l'adresse qui reçoit les alertes, la même que celle
  de ton compte Resend). Tu recevras un e-mail à chaque commande.

## Bon à savoir
- Les anciens articles et commandes de l'ancien site (InfinityFree) ne sont pas repris
  automatiquement : ré-ajoute les articles depuis l'administration.
- Le prix est toujours recalculé côté serveur à partir de la base : un client ne peut pas le modifier.
- Pour tester sur ordinateur : copie `.env.example` en `.env.local`, remplis-le, puis
  `npm install` et `npm run dev`.
